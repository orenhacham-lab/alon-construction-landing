/**
 * נתוני המותג והתוכן של דף הנחיתה.
 * ריכוז כל הטקסטים והפרטים במקום אחד לתחזוקה נוחה.
 */

export const COMPANY = {
  name: 'אלון עבודות בניה בע"מ',
  shortName: "אלון עבודות בניה",
  tagline: "בונים עולמות בשבילך",
  address: "מושב חדיד, הרחבה מספר 180",
  zip: "73135",
  email: "alonmor101@gmail.com",
  phonePrimary: "054-6217217",
  phoneSecondary: "08-9206564",
  fax: "08-9221011",
} as const;

/** קישורי פעולה (CTA) */
export const CONTACT = {
  telPrimary: "tel:0546217217",
  telSecondary: "tel:089206564",
  mailto: `mailto:${COMPANY.email}`,
  whatsappNumber: "972546217217",
  whatsappMessage:
    "היי, הגעתי דרך האתר ואשמח לקבל בדיקה מקצועית / הצעת מחיר לשיקום או חיזוק מבנה.",
} as const;

export const WHATSAPP_URL = `https://wa.me/${CONTACT.whatsappNumber}?text=${encodeURIComponent(
  CONTACT.whatsappMessage,
)}`;

/** סוגי הפנייה בטופס - הערך נשלח גם כ-lead_type ל-dataLayer */
export const SERVICE_OPTIONS = [
  { value: "restoration", label: "שיקום מבנה" },
  { value: "reinforcement", label: "חיזוק מבנה" },
  { value: "dangerous", label: "מבנה מסוכן" },
  { value: "concrete", label: "שיקום בטונים" },
  { value: "plaster", label: "טיח ושליכט" },
  { value: "preservation", label: "שימור מבנה" },
  { value: "other", label: "אחר" },
] as const;

export type ServiceValue = (typeof SERVICE_OPTIONS)[number]["value"];

export type ServiceOption = { readonly value: string; readonly label: string };

/** דף עבודות גמר: הודעת וואטסאפ וסוגי פנייה */
export const GMAR_WHATSAPP_URL = `https://wa.me/${CONTACT.whatsappNumber}?text=${encodeURIComponent(
  "היי, הגעתי מהאתר ואשמח לתאם פגישה בשטח לגבי עבודות גמר.",
)}`;

export const GMAR_SERVICE_OPTIONS = [
  { value: "finishing_full", label: "עבודות גמר לבית שלם" },
  { value: "gypsum", label: "עבודות גבס ותקרות" },
  { value: "flooring", label: "ריצוף וחיפוי" },
  { value: "woodwork", label: "פרגולה, דק או גדר עץ" },
  { value: "structure_finish", label: "שלד וגמר בפרויקט אחד" },
  { value: "renovation", label: "שיפוץ כללי" },
  { value: "other", label: "אחר" },
] as const;

export const ALL_SERVICE_OPTIONS: readonly ServiceOption[] = [
  ...SERVICE_OPTIONS,
  ...GMAR_SERVICE_OPTIONS,
];

/** כרטיסי שירותים */
export const SERVICES = [
  {
    icon: "concrete",
    title: "שיקום בטונים",
    text: "טיפול יסודי בבטון מתפורר, ברזל חשוף וקורוזיה, תוך החזרת חוזק וביטחון למבנה לאורך שנים.",
  },
  {
    icon: "reinforce",
    title: "חיזוק מבנים",
    text: "פתרונות הנדסיים לחיזוק מבנים קיימים, כולל היערכות לעמידות מוגברת ושיפור יציבות המבנה.",
  },
  {
    icon: "facade",
    title: "חידוש חזיתות",
    text: "החזרת מראה חדש ומרשים לחזית הבניין, עם גימור ברמה גבוהה שמעלה את ערך הנכס.",
  },
  {
    icon: "plaster",
    title: "עבודות טיח ושליכט",
    text: "ביצוע טיח, שליכט אקרילי וטיח שחור באיכות גבוהה, עם דיוק והקפדה על אחידות ועמידות.",
  },
  {
    icon: "danger",
    title: "טיפול במבנים מסוכנים",
    text: "אבחון, שיקום והסרת צו מבנה מסוכן בעבודה מול הרשויות, עד להחזרת המבנה למצב בטוח ותקין.",
  },
  {
    icon: "preserve",
    title: "שיקום מבנים לשימור",
    text: "עבודה רגישה ומדויקת על מבנים בעלי ערך אדריכלי, בהתאם לדרישות מחלקות השימור.",
  },
  {
    icon: "authority",
    title: "עבודה מול רשויות",
    text: "ניסיון בעבודה מול עיריות, חברות עירוניות וגופים ציבוריים, עמידה בדרישות ותיאום מלא.",
  },
  {
    icon: "occupied",
    title: "פרויקטים בבניינים מאוכלסים",
    text: "ביצוע עבודות מורכבות תוך שמירה על שגרת הדיירים, בטיחות מלאה וסביבת עבודה נקייה ומסודרת.",
  },
] as const;

/** נקודות כאב - מה שמטריד את בעל הנכס */
export const PAIN_POINTS = [
  "סדקים בקירות חיצוניים",
  "בטון מתפורר",
  "ברזל חשוף וחלודה",
  "נפילות טיח",
  "צו מבנה מסוכן",
  "חזית ישנה ומוזנחת",
  "צורך בשיקום לפני החמרת הנזק",
] as const;

/** פרויקטים לדוגמה */
export const PROJECTS = [
  {
    location: "נאות גולף, קיסריה",
    tag: "פרויקט רחב היקף",
    scene: "caesarea",
    image: "/images/projects/neot-golf-caesarea.jpg",
    title: "שיקום 10 בניינים במתחם נאות גולף קיסריה",
    text: "פרויקט רחב היקף לשיקום 10 בניינים במתחם מאוכלס, הכולל שיקום בטונים, טיפול בברזל חשוף, עבודות טיח, שליכט וריצוף. העבודה בוצעה תוך הקפדה על בטיחות הדיירים, שמירה על שגרת המגורים וניהול מדויק של שלבי הביצוע.",
    stats: [
      { value: "10", label: "בניינים" },
      { value: "100%", label: "מאוכלס" },
    ],
  },
  {
    location: "אזורי חן, תל אביב",
    tag: "הסרת צו מבנה מסוכן",
    scene: "azorei",
    image: "/images/projects/azorei-chen-tlv.jpg",
    title: "שיקום והסרת צו מבנה מסוכן",
    text: "שיקום שני בניינים בני 11 קומות במסגרת טיפול והסרת צו מבנה מסוכן. הפרויקט כלל גירוד פסיפס קיים, שיקום ברזל ובטון, ביצוע טיח שחור ושליכט אקרילי. העבודה בוצעה מול עזרה ובצרון, תוך עמידה בדרישות מקצועיות, בטיחותיות ותפעוליות מורכבות.",
    stats: [
      { value: "11", label: "קומות" },
      { value: "2", label: "בניינים" },
    ],
  },
  {
    location: "בלפור 2, תל אביב",
    tag: "מבנה לשימור",
    scene: "balfour",
    image: "/images/projects/balfour-2-tlv.jpg",
    title: "שיקום מבנה לשימור",
    text: "שיקום מבנה לשימור בן 6 קומות בלב תל אביב, תוך ביצוע עבודות טיח לשימור בהתאם לדרישות מחלקת השימור של עיריית תל אביב. הפרויקט דרש דיוק גבוה, עבודה רגישה מול מבנה בעל ערך אדריכלי ושמירה על אופי המבנה המקורי.",
    stats: [
      { value: "6", label: "קומות" },
      { value: "שימור", label: "אדריכלי" },
    ],
  },
] as const;

/** סיבות לבחור בנו */
export const WHY_US = [
  "ניסיון בפרויקטים מורכבים",
  "התמחות בשיקום בטונים וחיזוק מבנים",
  "עבודה מול רשויות וחברות עירוניות",
  "ניהול פרויקט מסודר משלב האבחון ועד הביצוע",
  "הקפדה על בטיחות הדיירים והעובדים",
  "עבודה נקייה ומסודרת בבניינים מאוכלסים",
  "רמת גימור גבוהה",
  "ליווי אישי לאורך כל הדרך",
] as const;

/** שלבי תהליך העבודה */
export const PROCESS_STEPS = [
  {
    title: "שיחת היכרות וקבלת פרטים",
    text: "מתחילים בשיחה קצרה כדי להבין את מצב המבנה, הצרכים והציפיות שלכם.",
  },
  {
    title: "בדיקה מקצועית של מצב המבנה",
    text: "מגיעים לשטח, בוחנים את הליקויים ומאבחנים את היקף העבודה הנדרש.",
  },
  {
    title: "בניית פתרון ותוכנית ביצוע",
    text: "מגבשים פתרון הנדסי מותאם, תוכנית עבודה מסודרת והצעת מחיר שקופה.",
  },
  {
    title: "ביצוע העבודה עד למסירה מסודרת",
    text: "מבצעים את העבודה ברמה גבוהה, עם פיקוח צמוד ומסירה נקייה ומסודרת.",
  },
] as const;

/** נקודות אמון ל-Hero */
export const TRUST_POINTS = [
  "ניסיון בפרויקטים מורכבים",
  "עבודה מול רשויות וחברות עירוניות",
  "טיפול במבנים מאוכלסים",
  "הקפדה על בטיחות ואיכות",
] as const;
